﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PeterCardLibrary;

namespace PeterCardLibrary
{
    public class humanPlayer
    {
        private PlayingCard humanCard;
        private int humanWins;
        private Deck deck;


   //    public PlayGame()
   //    {
   //        InitializeComponent();
   //        humanWins = 0;
   //        deck = new Deck(1);

   //    }



        


    }
}
