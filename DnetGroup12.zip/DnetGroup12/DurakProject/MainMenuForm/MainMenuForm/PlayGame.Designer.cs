﻿namespace MainMenuForm
{
    partial class frmPlayingInterface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPlayingInterface));
            this.pbCardImage33 = new PictureBox.PictureBox();
            this.pbCardImage34 = new PictureBox.PictureBox();
            this.pbCardImage21 = new PictureBox.PictureBox();
            this.pbCardImage22 = new PictureBox.PictureBox();
            this.pbCardImage19 = new PictureBox.PictureBox();
            this.pbCardImage20 = new PictureBox.PictureBox();
            this.pbCardImage17 = new PictureBox.PictureBox();
            this.pbCardImage18 = new PictureBox.PictureBox();
            this.pbCardImage15 = new PictureBox.PictureBox();
            this.pbCardImage16 = new PictureBox.PictureBox();
            this.pbCardImage13 = new PictureBox.PictureBox();
            this.pbCardImage14 = new PictureBox.PictureBox();
            this.pbCardImage23 = new PictureBox.PictureBox();
            this.pbCardImage24 = new PictureBox.PictureBox();
            this.pbCardImage25 = new PictureBox.PictureBox();
            this.pbCardImage26 = new PictureBox.PictureBox();
            this.pbCardImage27 = new PictureBox.PictureBox();
            this.pbCardImage28 = new PictureBox.PictureBox();
            this.pbCardImage29 = new PictureBox.PictureBox();
            this.pbCardImage30 = new PictureBox.PictureBox();
            this.pbCardImage31 = new PictureBox.PictureBox();
            this.pbCardImage32 = new PictureBox.PictureBox();
            this.pbCardImage12 = new PictureBox.PictureBox();
            this.pbCardImage11 = new PictureBox.PictureBox();
            this.pbCardImage10 = new PictureBox.PictureBox();
            this.pbCardImage9 = new PictureBox.PictureBox();
            this.pbCardImage8 = new PictureBox.PictureBox();
            this.pbCardImage7 = new PictureBox.PictureBox();
            this.pbCardImage6 = new PictureBox.PictureBox();
            this.pbCardImage5 = new PictureBox.PictureBox();
            this.pbCardImage4 = new PictureBox.PictureBox();
            this.pbCardImage3 = new PictureBox.PictureBox();
            this.pbCardImage2 = new PictureBox.PictureBox();
            this.pbCardImage35 = new PictureBox.PictureBox();
            this.lblCardsInDeck = new System.Windows.Forms.Label();
            this.lblGameplayStatus = new System.Windows.Forms.Label();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnTake = new System.Windows.Forms.Button();
            this.btnDiscard = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // pbCardImage33
            // 
            this.pbCardImage33.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage33.FaceUp = true;
            this.pbCardImage33.Location = new System.Drawing.Point(761, 285);
            this.pbCardImage33.Name = "pbCardImage33";
            this.pbCardImage33.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage33.Size = new System.Drawing.Size(58, 112);
            this.pbCardImage33.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage33.TabIndex = 42;
            this.pbCardImage33.Visible = false;
            // 
            // pbCardImage34
            // 
            this.pbCardImage34.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage34.FaceUp = true;
            this.pbCardImage34.Location = new System.Drawing.Point(697, 285);
            this.pbCardImage34.Name = "pbCardImage34";
            this.pbCardImage34.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage34.Size = new System.Drawing.Size(58, 112);
            this.pbCardImage34.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage34.TabIndex = 41;
            this.pbCardImage34.Visible = false;
            // 
            // pbCardImage21
            // 
            this.pbCardImage21.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage21.FaceUp = true;
            this.pbCardImage21.Location = new System.Drawing.Point(530, 285);
            this.pbCardImage21.Name = "pbCardImage21";
            this.pbCardImage21.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage21.Size = new System.Drawing.Size(58, 112);
            this.pbCardImage21.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage21.TabIndex = 40;
            this.pbCardImage21.Visible = false;
            // 
            // pbCardImage22
            // 
            this.pbCardImage22.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage22.FaceUp = true;
            this.pbCardImage22.Location = new System.Drawing.Point(466, 285);
            this.pbCardImage22.Name = "pbCardImage22";
            this.pbCardImage22.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage22.Size = new System.Drawing.Size(58, 112);
            this.pbCardImage22.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage22.TabIndex = 39;
            this.pbCardImage22.Visible = false;
            // 
            // pbCardImage19
            // 
            this.pbCardImage19.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage19.FaceUp = true;
            this.pbCardImage19.Location = new System.Drawing.Point(314, 285);
            this.pbCardImage19.Name = "pbCardImage19";
            this.pbCardImage19.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage19.Size = new System.Drawing.Size(58, 112);
            this.pbCardImage19.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage19.TabIndex = 38;
            this.pbCardImage19.Visible = false;
            // 
            // pbCardImage20
            // 
            this.pbCardImage20.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage20.FaceUp = true;
            this.pbCardImage20.Location = new System.Drawing.Point(250, 285);
            this.pbCardImage20.Name = "pbCardImage20";
            this.pbCardImage20.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage20.Size = new System.Drawing.Size(58, 112);
            this.pbCardImage20.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage20.TabIndex = 37;
            this.pbCardImage20.Visible = false;
            // 
            // pbCardImage17
            // 
            this.pbCardImage17.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage17.FaceUp = true;
            this.pbCardImage17.Location = new System.Drawing.Point(762, 167);
            this.pbCardImage17.Name = "pbCardImage17";
            this.pbCardImage17.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage17.Size = new System.Drawing.Size(58, 112);
            this.pbCardImage17.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage17.TabIndex = 36;
            this.pbCardImage17.Visible = false;
            // 
            // pbCardImage18
            // 
            this.pbCardImage18.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage18.FaceUp = true;
            this.pbCardImage18.Location = new System.Drawing.Point(698, 167);
            this.pbCardImage18.Name = "pbCardImage18";
            this.pbCardImage18.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage18.Size = new System.Drawing.Size(58, 112);
            this.pbCardImage18.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage18.TabIndex = 35;
            this.pbCardImage18.Visible = false;
            // 
            // pbCardImage15
            // 
            this.pbCardImage15.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage15.FaceUp = true;
            this.pbCardImage15.Location = new System.Drawing.Point(531, 167);
            this.pbCardImage15.Name = "pbCardImage15";
            this.pbCardImage15.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage15.Size = new System.Drawing.Size(58, 112);
            this.pbCardImage15.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage15.TabIndex = 34;
            this.pbCardImage15.Visible = false;
            // 
            // pbCardImage16
            // 
            this.pbCardImage16.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage16.FaceUp = true;
            this.pbCardImage16.Location = new System.Drawing.Point(467, 167);
            this.pbCardImage16.Name = "pbCardImage16";
            this.pbCardImage16.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage16.Size = new System.Drawing.Size(58, 112);
            this.pbCardImage16.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage16.TabIndex = 33;
            this.pbCardImage16.Visible = false;
            // 
            // pbCardImage13
            // 
            this.pbCardImage13.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage13.FaceUp = true;
            this.pbCardImage13.Location = new System.Drawing.Point(315, 167);
            this.pbCardImage13.Name = "pbCardImage13";
            this.pbCardImage13.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage13.Size = new System.Drawing.Size(58, 112);
            this.pbCardImage13.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage13.TabIndex = 32;
            this.pbCardImage13.Visible = false;
            // 
            // pbCardImage14
            // 
            this.pbCardImage14.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage14.FaceUp = true;
            this.pbCardImage14.Location = new System.Drawing.Point(251, 167);
            this.pbCardImage14.Name = "pbCardImage14";
            this.pbCardImage14.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage14.Size = new System.Drawing.Size(58, 112);
            this.pbCardImage14.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage14.TabIndex = 31;
            this.pbCardImage14.Visible = false;
            // 
            // pbCardImage23
            // 
            this.pbCardImage23.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage23.FaceUp = true;
            this.pbCardImage23.Location = new System.Drawing.Point(384, 423);
            this.pbCardImage23.Name = "pbCardImage23";
            this.pbCardImage23.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage23.Size = new System.Drawing.Size(80, 133);
            this.pbCardImage23.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage23.TabIndex = 30;
            // 
            // pbCardImage24
            // 
            this.pbCardImage24.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage24.FaceUp = true;
            this.pbCardImage24.Location = new System.Drawing.Point(458, 423);
            this.pbCardImage24.Name = "pbCardImage24";
            this.pbCardImage24.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage24.Size = new System.Drawing.Size(80, 133);
            this.pbCardImage24.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage24.TabIndex = 29;
            // 
            // pbCardImage25
            // 
            this.pbCardImage25.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage25.FaceUp = true;
            this.pbCardImage25.Location = new System.Drawing.Point(533, 423);
            this.pbCardImage25.Name = "pbCardImage25";
            this.pbCardImage25.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage25.Size = new System.Drawing.Size(80, 133);
            this.pbCardImage25.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage25.TabIndex = 28;
            // 
            // pbCardImage26
            // 
            this.pbCardImage26.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage26.FaceUp = true;
            this.pbCardImage26.Location = new System.Drawing.Point(610, 423);
            this.pbCardImage26.Name = "pbCardImage26";
            this.pbCardImage26.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage26.Size = new System.Drawing.Size(80, 133);
            this.pbCardImage26.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage26.TabIndex = 27;
            // 
            // pbCardImage27
            // 
            this.pbCardImage27.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage27.FaceUp = true;
            this.pbCardImage27.Location = new System.Drawing.Point(687, 423);
            this.pbCardImage27.Name = "pbCardImage27";
            this.pbCardImage27.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage27.Size = new System.Drawing.Size(80, 133);
            this.pbCardImage27.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage27.TabIndex = 26;
            // 
            // pbCardImage28
            // 
            this.pbCardImage28.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage28.FaceUp = true;
            this.pbCardImage28.Location = new System.Drawing.Point(762, 423);
            this.pbCardImage28.Name = "pbCardImage28";
            this.pbCardImage28.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage28.Size = new System.Drawing.Size(80, 133);
            this.pbCardImage28.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage28.TabIndex = 25;
            this.pbCardImage28.Visible = false;
            // 
            // pbCardImage29
            // 
            this.pbCardImage29.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage29.FaceUp = true;
            this.pbCardImage29.Location = new System.Drawing.Point(839, 423);
            this.pbCardImage29.Name = "pbCardImage29";
            this.pbCardImage29.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage29.Size = new System.Drawing.Size(80, 133);
            this.pbCardImage29.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage29.TabIndex = 24;
            this.pbCardImage29.Visible = false;
            // 
            // pbCardImage30
            // 
            this.pbCardImage30.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage30.FaceUp = true;
            this.pbCardImage30.Location = new System.Drawing.Point(308, 423);
            this.pbCardImage30.Name = "pbCardImage30";
            this.pbCardImage30.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage30.Size = new System.Drawing.Size(80, 133);
            this.pbCardImage30.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage30.TabIndex = 23;
            // 
            // pbCardImage31
            // 
            this.pbCardImage31.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage31.FaceUp = true;
            this.pbCardImage31.Location = new System.Drawing.Point(233, 423);
            this.pbCardImage31.Name = "pbCardImage31";
            this.pbCardImage31.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage31.Size = new System.Drawing.Size(80, 133);
            this.pbCardImage31.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage31.TabIndex = 22;
            this.pbCardImage31.Visible = false;
            // 
            // pbCardImage32
            // 
            this.pbCardImage32.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage32.FaceUp = true;
            this.pbCardImage32.Location = new System.Drawing.Point(157, 423);
            this.pbCardImage32.Name = "pbCardImage32";
            this.pbCardImage32.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage32.Size = new System.Drawing.Size(80, 133);
            this.pbCardImage32.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage32.TabIndex = 21;
            this.pbCardImage32.Visible = false;
            // 
            // pbCardImage12
            // 
            this.pbCardImage12.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage12.FaceUp = false;
            this.pbCardImage12.Location = new System.Drawing.Point(384, 12);
            this.pbCardImage12.Name = "pbCardImage12";
            this.pbCardImage12.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage12.Size = new System.Drawing.Size(80, 133);
            this.pbCardImage12.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage12.TabIndex = 10;
            // 
            // pbCardImage11
            // 
            this.pbCardImage11.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage11.FaceUp = false;
            this.pbCardImage11.Location = new System.Drawing.Point(458, 12);
            this.pbCardImage11.Name = "pbCardImage11";
            this.pbCardImage11.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage11.Size = new System.Drawing.Size(80, 133);
            this.pbCardImage11.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage11.TabIndex = 9;
            // 
            // pbCardImage10
            // 
            this.pbCardImage10.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage10.FaceUp = false;
            this.pbCardImage10.Location = new System.Drawing.Point(533, 12);
            this.pbCardImage10.Name = "pbCardImage10";
            this.pbCardImage10.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage10.Size = new System.Drawing.Size(80, 133);
            this.pbCardImage10.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage10.TabIndex = 8;
            // 
            // pbCardImage9
            // 
            this.pbCardImage9.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage9.FaceUp = false;
            this.pbCardImage9.Location = new System.Drawing.Point(610, 12);
            this.pbCardImage9.Name = "pbCardImage9";
            this.pbCardImage9.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage9.Size = new System.Drawing.Size(80, 133);
            this.pbCardImage9.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage9.TabIndex = 7;
            // 
            // pbCardImage8
            // 
            this.pbCardImage8.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage8.FaceUp = false;
            this.pbCardImage8.Location = new System.Drawing.Point(687, 12);
            this.pbCardImage8.Name = "pbCardImage8";
            this.pbCardImage8.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage8.Size = new System.Drawing.Size(80, 133);
            this.pbCardImage8.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage8.TabIndex = 6;
            // 
            // pbCardImage7
            // 
            this.pbCardImage7.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage7.FaceUp = false;
            this.pbCardImage7.Location = new System.Drawing.Point(762, 12);
            this.pbCardImage7.Name = "pbCardImage7";
            this.pbCardImage7.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage7.Size = new System.Drawing.Size(80, 133);
            this.pbCardImage7.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage7.TabIndex = 5;
            this.pbCardImage7.Visible = false;
            // 
            // pbCardImage6
            // 
            this.pbCardImage6.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage6.FaceUp = false;
            this.pbCardImage6.Location = new System.Drawing.Point(839, 12);
            this.pbCardImage6.Name = "pbCardImage6";
            this.pbCardImage6.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage6.Size = new System.Drawing.Size(80, 133);
            this.pbCardImage6.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage6.TabIndex = 4;
            this.pbCardImage6.Visible = false;
            // 
            // pbCardImage5
            // 
            this.pbCardImage5.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage5.FaceUp = false;
            this.pbCardImage5.Location = new System.Drawing.Point(12, 233);
            this.pbCardImage5.Name = "pbCardImage5";
            this.pbCardImage5.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage5.Size = new System.Drawing.Size(80, 133);
            this.pbCardImage5.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage5.TabIndex = 3;
            // 
            // pbCardImage4
            // 
            this.pbCardImage4.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage4.FaceUp = false;
            this.pbCardImage4.Location = new System.Drawing.Point(308, 12);
            this.pbCardImage4.Name = "pbCardImage4";
            this.pbCardImage4.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage4.Size = new System.Drawing.Size(80, 133);
            this.pbCardImage4.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage4.TabIndex = 2;
            // 
            // pbCardImage3
            // 
            this.pbCardImage3.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage3.FaceUp = false;
            this.pbCardImage3.Location = new System.Drawing.Point(233, 12);
            this.pbCardImage3.Name = "pbCardImage3";
            this.pbCardImage3.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage3.Size = new System.Drawing.Size(80, 133);
            this.pbCardImage3.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage3.TabIndex = 1;
            this.pbCardImage3.Visible = false;
            // 
            // pbCardImage2
            // 
            this.pbCardImage2.CardOrientation = System.Windows.Forms.Orientation.Vertical;
            this.pbCardImage2.FaceUp = false;
            this.pbCardImage2.Location = new System.Drawing.Point(157, 12);
            this.pbCardImage2.Name = "pbCardImage2";
            this.pbCardImage2.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage2.Size = new System.Drawing.Size(80, 133);
            this.pbCardImage2.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage2.TabIndex = 0;
            this.pbCardImage2.Visible = false;
            // 
            // pbCardImage35
            // 
            this.pbCardImage35.CardOrientation = System.Windows.Forms.Orientation.Horizontal;
            this.pbCardImage35.FaceUp = true;
            this.pbCardImage35.Location = new System.Drawing.Point(34, 264);
            this.pbCardImage35.Name = "pbCardImage35";
            this.pbCardImage35.Rank = PeterCardLibrary.Rank.Ace;
            this.pbCardImage35.Size = new System.Drawing.Size(133, 80);
            this.pbCardImage35.Suit = PeterCardLibrary.Suit.Spades;
            this.pbCardImage35.TabIndex = 43;
            // 
            // lblCardsInDeck
            // 
            this.lblCardsInDeck.Location = new System.Drawing.Point(14, 199);
            this.lblCardsInDeck.Name = "lblCardsInDeck";
            this.lblCardsInDeck.Size = new System.Drawing.Size(123, 23);
            this.lblCardsInDeck.TabIndex = 44;
            this.lblCardsInDeck.Text = "# of Cards left in Deck";
            this.lblCardsInDeck.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGameplayStatus
            // 
            this.lblGameplayStatus.Location = new System.Drawing.Point(393, 570);
            this.lblGameplayStatus.Name = "lblGameplayStatus";
            this.lblGameplayStatus.Size = new System.Drawing.Size(298, 32);
            this.lblGameplayStatus.TabIndex = 46;
            this.lblGameplayStatus.Text = "Gameplay Status update";
            this.lblGameplayStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnReturn
            // 
            this.btnReturn.Location = new System.Drawing.Point(17, 544);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(75, 44);
            this.btnReturn.TabIndex = 47;
            this.btnReturn.Text = "Return To Main Menu";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnTake
            // 
            this.btnTake.Location = new System.Drawing.Point(882, 245);
            this.btnTake.Name = "btnTake";
            this.btnTake.Size = new System.Drawing.Size(63, 49);
            this.btnTake.TabIndex = 48;
            this.btnTake.Text = "Take Card(s)";
            this.btnTake.UseVisualStyleBackColor = true;
            // 
            // btnDiscard
            // 
            this.btnDiscard.Location = new System.Drawing.Point(882, 317);
            this.btnDiscard.Name = "btnDiscard";
            this.btnDiscard.Size = new System.Drawing.Size(63, 49);
            this.btnDiscard.TabIndex = 49;
            this.btnDiscard.Text = "Discard Card(s)";
            this.btnDiscard.UseVisualStyleBackColor = true;
            // 
            // frmPlayingInterface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1008, 600);
            this.Controls.Add(this.btnDiscard);
            this.Controls.Add(this.btnTake);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.lblGameplayStatus);
            this.Controls.Add(this.lblCardsInDeck);
            this.Controls.Add(this.pbCardImage33);
            this.Controls.Add(this.pbCardImage34);
            this.Controls.Add(this.pbCardImage21);
            this.Controls.Add(this.pbCardImage22);
            this.Controls.Add(this.pbCardImage19);
            this.Controls.Add(this.pbCardImage20);
            this.Controls.Add(this.pbCardImage17);
            this.Controls.Add(this.pbCardImage18);
            this.Controls.Add(this.pbCardImage15);
            this.Controls.Add(this.pbCardImage16);
            this.Controls.Add(this.pbCardImage13);
            this.Controls.Add(this.pbCardImage14);
            this.Controls.Add(this.pbCardImage23);
            this.Controls.Add(this.pbCardImage24);
            this.Controls.Add(this.pbCardImage25);
            this.Controls.Add(this.pbCardImage26);
            this.Controls.Add(this.pbCardImage27);
            this.Controls.Add(this.pbCardImage28);
            this.Controls.Add(this.pbCardImage29);
            this.Controls.Add(this.pbCardImage30);
            this.Controls.Add(this.pbCardImage31);
            this.Controls.Add(this.pbCardImage32);
            this.Controls.Add(this.pbCardImage12);
            this.Controls.Add(this.pbCardImage11);
            this.Controls.Add(this.pbCardImage10);
            this.Controls.Add(this.pbCardImage9);
            this.Controls.Add(this.pbCardImage8);
            this.Controls.Add(this.pbCardImage7);
            this.Controls.Add(this.pbCardImage6);
            this.Controls.Add(this.pbCardImage5);
            this.Controls.Add(this.pbCardImage4);
            this.Controls.Add(this.pbCardImage3);
            this.Controls.Add(this.pbCardImage2);
            this.Controls.Add(this.pbCardImage35);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmPlayingInterface";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Playing Interface";
            this.Load += new System.EventHandler(this.PlayGame_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private PictureBox.PictureBox pbCardImage1;
        private PictureBox.PictureBox pbCardImage2;
        private PictureBox.PictureBox pbCardImage3;
        private PictureBox.PictureBox pbCardImage4;
        private PictureBox.PictureBox pbCardImage5;
        private PictureBox.PictureBox pbCardImage6;
        private PictureBox.PictureBox pbCardImage7;
        private PictureBox.PictureBox pbCardImage8;
        private PictureBox.PictureBox pbCardImage9;
        private PictureBox.PictureBox pbCardImage10;
        private PictureBox.PictureBox pbCardImage11;
        private PictureBox.PictureBox pbCardImage12;
        private PictureBox.PictureBox pbCardImage23;
        private PictureBox.PictureBox pbCardImage24;
        private PictureBox.PictureBox pbCardImage25;
        private PictureBox.PictureBox pbCardImage26;
        private PictureBox.PictureBox pbCardImage27;
        private PictureBox.PictureBox pbCardImage28;
        private PictureBox.PictureBox pbCardImage29;
        private PictureBox.PictureBox pbCardImage30;
        private PictureBox.PictureBox pbCardImage31;
        private PictureBox.PictureBox pbCardImage32;
        private PictureBox.PictureBox pbCardImage13;
        private PictureBox.PictureBox pbCardImage14;
        private PictureBox.PictureBox pbCardImage15;
        private PictureBox.PictureBox pbCardImage16;
        private PictureBox.PictureBox pbCardImage17;
        private PictureBox.PictureBox pbCardImage18;
        private PictureBox.PictureBox pbCardImage19;
        private PictureBox.PictureBox pbCardImage20;
        private PictureBox.PictureBox pbCardImage21;
        private PictureBox.PictureBox pbCardImage22;
        private PictureBox.PictureBox pbCardImage33;
        private PictureBox.PictureBox pbCardImage34;
        private PictureBox.PictureBox pbCardImage35;
        private System.Windows.Forms.Label lblCardsInDeck;
        private System.Windows.Forms.Label lblGameplayStatus;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Button btnTake;
        private System.Windows.Forms.Button btnDiscard;
    }
}