﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MainMenuForm
{
    public partial class frmMainMenuForm : Form
    {
        public frmMainMenuForm()
        {
            InitializeComponent();
        }

        private void btnRules_Click(object sender, EventArgs e)
        {
            frmRules f2 = new frmRules();
            f2.ShowDialog(); // Shows frmRules

        }

        private void About_Click(object sender, EventArgs e)
        {
            frmAbout f3 = new frmAbout();
            f3.ShowDialog(); // Shows frmAbout
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            frmSettings f4 = new frmSettings();
            f4.ShowDialog(); // Shows frmSettings
        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cmbDeckSize.Text))
            {
                MessageBox.Show("No selection made! Please select a deck size!",
                    "Warming",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning,
                    MessageBoxDefaultButton.Button1); //No item select message
            }
            else if (cmbDeckSize.Text == "20 Card Deck")
            {
                frmPlayingInterface f5 = new frmPlayingInterface();
                f5.ShowDialog(); // Shows frmPlayingInterface //play 20 cards
            }
            else if (cmbDeckSize.Text == "36 Card Deck")
            {
                frmPlayingInterface f5 = new frmPlayingInterface();
                f5.ShowDialog(); // Shows frmPlayingInterface //play 36 cards
            }
            else
            {
                frmPlayingInterface f5 = new frmPlayingInterface();
                f5.ShowDialog(); // Shows frmPlayingInterface //play 52 cards
            }

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // Closes the form when clicked
            this.Close();
        }

        private void frmMainMenuForm_Load(object sender, EventArgs e)
        {
            // Add items to combobox
            cmbDeckSize.Items.Add("");
            cmbDeckSize.Items.Add("20 Card Deck");
            cmbDeckSize.Items.Add("36 Card Deck");
            cmbDeckSize.Items.Add("52 Card Deck");
        }

    }
}
