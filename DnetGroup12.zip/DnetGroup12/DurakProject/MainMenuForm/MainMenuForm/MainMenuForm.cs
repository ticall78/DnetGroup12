﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MainMenuForm
{
    public partial class frmMainMenuForm : Form
    {
        public frmMainMenuForm()
        {
            InitializeComponent();
        }

        private void btnRules_Click(object sender, EventArgs e)
        {
            frmRules f2 = new frmRules();
            f2.ShowDialog(); // Shows frmRules

        }

        private void About_Click(object sender, EventArgs e)
        {
            frmAbout f3 = new frmAbout();
            f3.ShowDialog(); // Shows frmAbout
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            frmSettings f4 = new frmSettings();
            f4.ShowDialog(); // Shows frmSettings
        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cmbDeckSize.Text))
            {
                MessageBox.Show("No Item is Selected"); //No item select message
            }
            else if (cmbDeckSize.Text == "20")
            {
                //play 20 cards
            }
            else if (cmbDeckSize.Text == "36")
            {
                //play 36 cards
            }
            else
            {
                //play 52 cards
            }

            frmPlayingInterface f5 = new frmPlayingInterface();
            f5.ShowDialog(); // Shows frmPlayingInterface
            
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // Closes the form when clicked
            this.Close();
        }

        private void frmMainMenuForm_Load(object sender, EventArgs e)
        {
            cmbDeckSize.Items.Add("20");
            cmbDeckSize.Items.Add("36");
            cmbDeckSize.Items.Add("52");
        }

    }
}
